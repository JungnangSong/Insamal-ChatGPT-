#!/usr/bin/env python3
"""류경기체 인사말씀 HWPX 생성기

우수사례 원고(<귀향> 특별상영 인사말씀, 홍보담당관)의 HWPX를 서식 원본으로 써서
표지(로고·제목·개요 표·부서)와 본문 서식(꼭지 제목, ○ 글머리표, ■ 참고 박스)을 그대로 살리고
글자만 바꿔 넣는다.

사용법:
    python3 make_hwpx.py 원고.json 결과.hwpx

원고.json 모양:
{
  "title": "자원봉사자의 날 기념식",          # 표지 큰 제목(14자 안팎, 한 줄에 들어가게)
  "label": "인  사  말  씀",                  # 표지 가운데 글자(격려사·대회사·말씀자료·요청서 등)
  "rows": ["○ 일시 : ...", "○ 장소 : ...", "○ 참석 : ...", "○ 내용 : ..."],  # 개요 표 4칸
  "dept": "복지정책과",
  "blocks": [
    ["h", "1. 첫인사 및 감사인사"],          # 꼭지 제목
    ["i", "안녕하십니까. 중랑구청장 류경기입니다."],  # ○ 항목(온점·쉼표 줄바꿈 자동)
    ["p", "글머리표 없는 줄"],                 # 요청서 같은 일반 줄
    ["b", "박스 제목", ["- 줄1", "- 줄2"]],     # ■ 참고 박스(12pt)
    ["e", "감사합니다."]                       # 맨 끝 줄
  ]
}

규칙(사용자 요청, 2026. 10. 13.)
- 본문(○ 항목)과 꼭지 제목은 함초롱바탕 15pt. ■ 참고 박스는 원본대로 12pt
- 본문 줄나눔은 어절 단위("여러분" 같은 낱말이 줄 끝에서 쪼개지지 않게)
- 한 호흡(온점·쉼표 사이)이 한 줄을 넘으면 말이 끊기는 어절 뒤에서 두 줄로 나눈다(한 어절만 떨어지는 꼬리 줄 금지)
- ○ 항목 안에서 온점·쉼표 뒤에 줄을 바꾼다. 다음 줄은 한글이 ○ 뒤 글자 위치로 자동 들여 쓴다(숫자 속 점·쉼표, 짧은 인사, 너무 짧은 조각은 제외)
- ■ 박스의 "- 항목 : 내용" 줄은 내어쓰기로, 줄이 넘어가면 내용 첫 글자 아래에 맞춘다
- 사람이 확인할 곳(○○○, [확인 필요], (보완 바람), (확인 바람), 박스의 '보완 바람·확인 바람')은 노란 형광펜
"""
import json, os, random, re, struct, sys, zipfile, zlib
from xml.sax.saxutils import escape as esc

HERE = os.path.dirname(os.path.abspath(__file__))
TPL = next((p for p in [os.path.join(HERE, 'template_insamal.hwpx'),
            '/mnt/data/template_insamal.hwpx',
            os.path.join(HERE, '..', 'assets', 'template_insamal.hwpx')] if os.path.exists(p)),
           '/mnt/data/template_insamal.hwpx')

# ── 서식 원본에서 문단 틀 꺼내기 ──
_src = zipfile.ZipFile(TPL)
_x = _src.read('Contents/section0.xml').decode('utf-8')
_hs = _x.find('>', _x.find('<hs:sec')) + 1
HEAD, TAIL = _x[:_hs], _x[_x.rfind('</hs:sec>'):]
_body = _x[_hs:_x.rfind('</hs:sec>')]
PARAS, _d = [], 0
for _m in re.finditer(r'<(/?)hp:p\b[^>]*?(/?)>', _body):
    if _m.group(1) == '' and _m.group(2) == '':
        if _d == 0:
            _st = _m.start()
        _d += 1
    elif _m.group(1) == '/':
        _d -= 1
        if _d == 0:
            PARAS.append(_body[_st:_m.end()])
assert len(PARAS) == 58, '서식 원본이 바뀌었습니다'

def noseg(p):
    return re.sub(r'<hp:linesegarray>.*?</hp:linesegarray>', '', p, flags=re.S)

T_HEAD, T_HEAD_SP = noseg(PARAS[11]), noseg(PARAS[12])
T_ITEM, T_ITEM_SP = noseg(PARAS[15]), noseg(PARAS[16])
T_SEC_SP, T_END, T_BOX = noseg(PARAS[21]), noseg(PARAS[57]), noseg(PARAS[47])

# ── 형광펜 ──
MARK = re.compile(r'(○○○|\[확인 필요[^\]]*\]|\((?:내용 )?보완 바람\)|\(확인 바람\)|\(추진 여부 확인 바람\))')

def hl(text):
    out, last = [], 0
    for m in MARK.finditer(text):
        out.append(esc(text[last:m.start()]))
        out.append(f'<hp:markpenBegin color="#FFFF00"/>{esc(m.group(0))}<hp:markpenEnd/>')
        last = m.end()
    out.append(esc(text[last:]))
    return ''.join(out)

# ── 온점·쉼표 줄바꿈 ──
BRK = re.compile(r'(?:(?<=[가-힣\)\]’”])\.|(?<=[가-힣\)\]’”%0-9]),)\s+')  # 쉼표는 숫자·% 뒤도 허용(천 단위 쉼표 1,266은 뒤에 빈칸이 없어 제외)

def wrap(text, min_comma=12, min_tail=6, min_period=10):
    segs, start = [], 0
    for m in BRK.finditer(text):
        mark = text[m.start()]
        piece, tail = text[start:m.start() + 1], text[m.end():]
        if len(tail.strip()) < min_tail:
            continue
        if mark == ',' and len(piece.strip()) < min_comma:
            continue
        if mark == '.' and len(piece.strip()) < min_period:
            continue
        segs.append(piece); start = m.end()
    segs.append(text[start:])
    lines = []
    for seg in segs:
        lines += fit_lines(seg.strip())
    return '<hp:lineBreak/>'.join(hl(x) for x in lines)

# ── 한 호흡이 한 줄을 넘으면 두 줄로 ──
# 본문 함초롱바탕 15pt, 쪽 글자 폭 48,188(HWPUNIT)에서 ○ 글머리표 자리를 빼면 한 줄은 약 30자(한글 기준).
# 글꼴 실제 폭보다 조금 좁게 잡아, 줄 끝에 "여러분," 같은 한 어절만 떨어지는 꼬리 줄을 막는다.
LINE_EM = 29.0
GOOD_END = tuple('는은을를이가에서고며로도게지면데니요')
# 줄 첫머리에 오면 앞말과 떨어져 어색한 낱말(앞말에 기대는 말)
NO_START = {'위해', '위한', '위하여', '한', '하는', '하고', '함께', '등', '수', '것', '것이', '때', '중', '및', '같은', '대한', '통해', '따라', '있는', '있도록'}
MIN_HEAD, MIN_TAIL = 12.0, 8.0   # 나눈 첫 줄·둘째 줄의 최소 길이(한글 글자 수 기준)

def _w(t):
    w = 0.0
    for c in t:
        if re.match(r'[가-힣○■]', c): w += 1.0
        elif c == ' ': w += 0.5
        elif c.isdigit() or re.match(r'[A-Za-z%]', c): w += 0.55
        else: w += 0.4
    return w

def fit_lines(seg):
    """한 호흡(온점·쉼표 사이)이 한 줄에 들어가면 그대로 둔다.
    넘치면 첫 줄을 최대한 채우되, '~는 / ~을 / ~고'처럼 말이 끊기는 어절 뒤에서 나눈다.
    둘째 줄이 한두 어절만 남는 꼬리 줄은 만들지 않는다."""
    if _w(seg) <= LINE_EM or ' ' not in seg:
        return [seg]
    words = seg.split(' ')
    ok = []
    for i in range(1, len(words)):
        a, b = ' '.join(words[:i]), ' '.join(words[i:])
        if MIN_HEAD <= _w(a) <= LINE_EM and _w(b) >= MIN_TAIL and words[i] not in NO_START:
            ok.append((i, a, b, words[i - 1].endswith(GOOD_END)))
    if not ok:
        return [seg]
    good = [x for x in ok if x[3]]
    i, a, b, _ = (good or ok)[-1]
    return [a] + fit_lines(b)

def _set(tpl, inner):
    return re.sub(r'<hp:t>.*?</hp:t>', lambda m: f'<hp:t>{inner}</hp:t>', tpl, count=1, flags=re.S)

def head_p(t): return _set(T_HEAD, hl(t))
def item_p(t): return _set(T_ITEM, wrap(t))
def end_p(t): return _set(T_END, wrap(t))
def plain_p(t):
    return (f'<hp:p id="0" paraPrIDRef="30" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">'
            f'<hp:run charPrIDRef="32"><hp:t>{hl(t)}</hp:t></hp:run></hp:p>')

# ■ 박스 줄 내어쓰기: "- 항목 : 내용"에서 줄이 넘어가면 내용 첫 글자 아래로 맞춘다.
#   항목 길이가 줄마다 달라서 줄마다 내어쓰기 폭을 계산해 문단 모양을 새로 만든다.
BOX_PT = 1200          # 박스 글자 12pt(HWPUNIT)
BOX_BASE = 1100        # "- "가 시작하는 들여쓰기(■ 아래 한 글자쯤)
HANG = {}              # 내어쓰기 폭 → 새 paraPr 번호 (fix_header가 머리말에 추가)
FIRST_NEW_PARA = None  # 서식 원본의 문단 모양 개수(fix_header가 채움)

def _em(ch):
    if re.match(r'[가-힣ㄱ-ㅎㅏ-ㅣ一-鿿■□○◎]', ch): return 1.0
    if ch == ' ': return 0.5
    if ch.isdigit() or re.match(r'[A-Za-z%]', ch): return 0.55
    if ch in '()[]:;.,\'’‘`': return 0.33
    return 0.5

def _hang_width(label):
    return int(round(sum(_em(c) for c in label) * BOX_PT))

def _hang_para(width):
    if width not in HANG:
        HANG[width] = len(HANG)
    return f'@HANG{HANG[width]}@'   # fix_header 뒤에 실제 번호로 바꾼다

def box_p(title, lines):
    ps = [f'<hp:p id="0" paraPrIDRef="17" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">'
          f'<hp:run charPrIDRef="28"><hp:t>■ </hp:t></hp:run><hp:run charPrIDRef="46"><hp:t>{esc(title)}</hp:t></hp:run></hp:p>']
    for l in lines:
        l = l.strip()
        m = re.match(r'^(.*?\s:\s)', l) or re.match(r'^([-·•※]\s*)', l)
        label = m.group(1) if m else ''
        pid = _hang_para(_hang_width(label))
        k = re.search(r'(보완 바람|확인 바람|확인 필요)', l)
        if k:
            run = (f'<hp:run charPrIDRef="27"><hp:t><hp:markpenBegin color="#FFFF00"/>{esc(l[:k.start()])}</hp:t></hp:run>'
                   f'<hp:run charPrIDRef="46"><hp:t>{esc(l[k.start():])}<hp:markpenEnd/></hp:t></hp:run>')
        else:
            run = f'<hp:run charPrIDRef="27"><hp:t>{esc(l)}</hp:t></hp:run>'
        ps.append(f'<hp:p id="0" paraPrIDRef="{pid}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">{run}</hp:p>')
    # 표 높이(한글이 내용에 맞춰 다시 잡지만, 처음 값도 줄 수에 맞춘다)
    h = 282 + (1 + sum(1 + len(l) // 40 for l in lines)) * 2000
    b = re.sub(r'<hp:subList (.*?)>.*</hp:subList>', lambda m: f'<hp:subList {m.group(1)}>' + ''.join(ps) + '</hp:subList>', T_BOX, flags=re.S)
    b = b.replace('height="12848"', f'height="{h}"')
    return re.sub(r'<hp:tbl id="\d+"', f'<hp:tbl id="{random.randint(1000000000, 2100000000)}"', b)

def cover(title, label, rows, dept):
    c = [noseg(p) for p in PARAS[:11]]
    c[0] = PARAS[0]
    assert '&lt;귀향&gt; 특별상영 인사말씀' in c[2]
    c[2] = c[2].replace('&lt;귀향&gt; 특별상영 인사말씀', esc(title))
    # 가운데 글자는 '공백 run + 글자 run' 두 조각이다. 글자 run만 바꾼다(앞 run을 바꾸면 두 번 나온다)
    assert '<hp:t>인  사  말  씀</hp:t>' in c[4]
    c[4] = c[4].replace('<hp:t>인  사  말  씀</hp:t>', f'<hp:t>{esc(label)}</hp:t>')
    cells = list(re.finditer(r'<hp:tc .*?</hp:tc>', c[5], re.S))
    assert len(cells) == 4 and len(rows) == 4
    out, last = [], 0
    for cell, text in zip(cells, rows):
        s = re.sub(r'(<hp:p [^>]*>)(.*?)(</hp:p>)',
                   lambda m: m.group(1) + f'<hp:run charPrIDRef="20"><hp:t>{esc(text)}</hp:t></hp:run>' + m.group(3),
                   cell.group(0), count=1, flags=re.S)
        out += [c[5][last:cell.start()], s]; last = cell.end()
    out.append(c[5][last:]); c[5] = ''.join(out)
    assert '(홍보담당관)' in c[9]
    c[9] = c[9].replace('(홍보담당관)', esc(f'({dept})'))
    return c


BODY_FONT = '함초롱바탕'

def fix_header(h):
    """본문 서식을 사용자 기준으로 바꾼다.
    - 꼭지 제목(charPr 29)·본문(charPr 32): 14pt → 15pt, 한컴바탕 → 함초롱바탕
    - ○ 항목(paraPr 29)·끝 줄(paraPr 41)·일반 줄(paraPr 30): 한글 줄나눔을 어절 단위로
      (한컴 HWPX에서 breakNonLatinWord="KEEP_WORD"는 글자 단위, "BREAK_WORD"가 어절 단위로 동작한다)"""
    # 글꼴: 언어 묶음마다 한컴바탕 항목을 복사해 함초롱바탕을 새 번호로 추가
    new_ids = {}
    def add_font(m):
        lang, cnt, body = m.group(1), int(m.group(2)), m.group(3)
        fm = re.search(r'<hh:font id="(\d+)" face="한컴바탕".*?</hh:font>', body, re.S)
        assert fm, lang
        nid = cnt
        new = re.sub(r'id="\d+" face="한컴바탕"', f'id="{nid}" face="{BODY_FONT}"', fm.group(0), count=1)
        new_ids[lang] = nid
        return f'<hh:fontface lang="{lang}" fontCnt="{cnt + 1}">{body}{new}</hh:fontface>'
    h = re.sub(r'<hh:fontface lang="(\w+)" fontCnt="(\d+)">(.*?)</hh:fontface>', add_font, h, flags=re.S)
    keys = {'HANGUL': 'hangul', 'LATIN': 'latin', 'HANJA': 'hanja', 'JAPANESE': 'japanese', 'OTHER': 'other', 'SYMBOL': 'symbol', 'USER': 'user'}
    ref = '<hh:fontRef ' + ' '.join(f'{keys[k]}="{v}"' for k, v in new_ids.items()) + '/>'
    for cid in ('29', '32'):
        m = re.search(rf'<hh:charPr id="{cid}" height="1400".*?</hh:charPr>', h, re.S)
        assert m, cid
        c = m.group(0).replace(f'<hh:charPr id="{cid}" height="1400"', f'<hh:charPr id="{cid}" height="1500"', 1)
        c = re.sub(r'<hh:fontRef [^>]*/>', ref, c, count=1)
        h = h[:m.start()] + c + h[m.end():]
    for pid in ('29', '30', '41'):
        m = re.search(rf'<hh:paraPr id="{pid}".*?</hh:paraPr>', h, re.S)
        assert m, pid
        p = m.group(0).replace('breakNonLatinWord="KEEP_WORD"', 'breakNonLatinWord="BREAK_WORD"')
        h = h[:m.start()] + p + h[m.end():]
    # ■ 박스 줄의 내어쓰기 문단 모양: 박스 문단(paraPr 17)을 복사해 왼쪽 여백과 내어쓰기만 바꾼다.
    # hp:case는 글자 크기와 같은 단위, hp:default는 그 두 배로 적는다(서식 원본과 같은 방식).
    global FIRST_NEW_PARA
    cnt = int(re.search(r'<hh:paraProperties itemCnt="(\d+)">', h).group(1))
    FIRST_NEW_PARA = cnt
    base = re.search(r'<hh:paraPr id="17".*?</hh:paraPr>', h, re.S).group(0)
    adds = []
    for width, k in sorted(HANG.items(), key=lambda x: x[1]):
        q = base.replace('<hh:paraPr id="17"', f'<hh:paraPr id="{cnt + k}"', 1)
        q = q.replace('breakNonLatinWord="KEEP_WORD"', 'breakNonLatinWord="BREAK_WORD"')
        def mg(scale):
            return (f'<hh:margin><hc:intent value="{-width * scale}" unit="HWPUNIT"/><hc:left value="{BOX_BASE * scale}" unit="HWPUNIT"/>'
                    f'<hc:right value="0" unit="HWPUNIT"/><hc:prev value="0" unit="HWPUNIT"/><hc:next value="0" unit="HWPUNIT"/></hh:margin>')
        q = re.sub(r'(<hp:case[^>]*>)<hh:margin>.*?</hh:margin>', lambda m: m.group(1) + mg(1), q, count=1, flags=re.S)
        q = re.sub(r'(<hp:default>)<hh:margin>.*?</hh:margin>', lambda m: m.group(1) + mg(2), q, count=1, flags=re.S)
        adds.append(q)
    h = h.replace(f'<hh:paraProperties itemCnt="{cnt}">', f'<hh:paraProperties itemCnt="{cnt + len(adds)}">', 1)
    h = h.replace('</hh:paraProperties>', ''.join(adds) + '</hh:paraProperties>', 1)
    return h

# ── 미리보기 그림 ──
def _white_png(w=724, h=1024):
    raw = b''.join(b'\x00' + b'\xff' * (w * 3) for _ in range(h))
    def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')

def preview(title, label, rows, dept):
    """원본 미리보기 위에 새 표지 글자를 그린다. 글꼴이나 PIL이 없으면 흰 그림(옛 표지가 남지 않게)."""
    try:
        import io
        from PIL import Image, ImageDraw, ImageFont
        fb = next(f for f in ['/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', 'C:/Windows/Fonts/malgunbd.ttf'] if os.path.exists(f))
        fr = next(f for f in ['/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 'C:/Windows/Fonts/malgun.ttf'] if os.path.exists(f))
        im = Image.open(io.BytesIO(_src.read('Preview/PrvImage.png'))).convert('RGB'); d = ImageDraw.Draw(im); W = (255, 255, 255)
        d.rectangle([80, 222, 690, 322], fill=W)
        f = ImageFont.truetype(fb, 40); d.text(((724 - d.textlength(title, font=f)) / 2, 245), title, font=f, fill=(0, 0, 0))
        d.rectangle([150, 400, 580, 480], fill=W)
        f = ImageFont.truetype(fb, 48); d.text(((724 - d.textlength(label, font=f)) / 2, 410), label, font=f, fill=(15, 40, 120))
        f2 = ImageFont.truetype(fr, 15)
        for (a, b), s in zip([(516, 546), (552, 582), (587, 616), (622, 650)], rows):
            d.rectangle([158, a, 567, b], fill=W); d.text((165, a + 4), s.replace('○', 'o'), font=f2, fill=(0, 0, 0))
        d.line([(569, 512), (569, 652)], fill=(0, 0, 0)); d.line([(155, 512), (155, 652)], fill=(0, 0, 0))
        d.rectangle([200, 815, 530, 870], fill=W)
        f3 = ImageFont.truetype(fb, 34); t = f'({dept})'; d.text(((724 - d.textlength(t, font=f3)) / 2, 815), t, font=f3, fill=(0, 0, 0))
        buf = io.BytesIO(); im.save(buf, 'PNG'); return buf.getvalue()
    except Exception:
        return _white_png()

def build(spec, out_path):
    body, prev = [], None
    for b in spec['blocks']:
        k = b[0]
        if k == 'h':
            if prev is not None: body.append(T_SEC_SP)
            body += [head_p(b[1]), T_HEAD_SP]
        elif k in ('i', 'p', 'e'):
            if prev in ('i', 'p', 'e'): body.append(T_ITEM_SP)
            body.append({'i': item_p, 'p': plain_p, 'e': end_p}[k](b[1]))
        elif k == 'b':
            body.append(box_p(b[1], b[2]))
        else:
            raise ValueError(f'알 수 없는 블록: {k}')
        prev = k
    title, label, rows, dept = spec['title'], spec.get('label', '인  사  말  씀'), spec['rows'], spec['dept']
    xml = HEAD + ''.join(cover(title, label, rows, dept)) + ''.join(body) + TAIL
    header = fix_header(_src.read('Contents/header.xml').decode('utf-8'))
    xml = re.sub(r'@HANG(\d+)@', lambda m: str(FIRST_NEW_PARA + int(m.group(1))), xml)
    prv_txt = '\n'.join([title, label] + rows + ['중 랑 구', f'({dept})']) + '\n'
    with zipfile.ZipFile(out_path, 'w') as z:
        for info in _src.infolist():
            data = _src.read(info.filename)
            if info.filename == 'Contents/section0.xml':
                data = xml.encode('utf-8')
            elif info.filename == 'Contents/header.xml':
                data = header.encode('utf-8')
            elif info.filename == 'Preview/PrvText.txt':
                data = prv_txt.encode('utf-8')
            elif info.filename == 'Preview/PrvImage.png':
                data = preview(title, label, rows, dept)
            zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            zi.compress_type = info.compress_type
            z.writestr(zi, data)
    check(out_path, spec)

def check(path, spec):
    """만든 파일에서 실제 글자를 다시 꺼내 표지를 확인한다(미리보기 그림만 보고 넘어가지 않는다)."""
    import xml.dom.minidom
    x = zipfile.ZipFile(path).read('Contents/section0.xml').decode('utf-8')
    xml.dom.minidom.parseString(x)
    texts = [re.sub(r'<[^>]+>', '', t) for t in re.findall(r'<hp:t>(.*?)</hp:t>', x, re.S)]
    label = spec.get('label', '인  사  말  씀')
    problems = []
    if sum(t.count(label.strip()) for t in texts[:10]) != 1:
        problems.append('표지 가운데 글자가 한 번이 아님')
    for old in ('귀향', '홍보담당관', '중랑양원미디어센터'):
        if old in x and old not in json.dumps(spec, ensure_ascii=False):
            problems.append(f'원본 글자 남음: {old}')
    if problems:
        raise SystemExit('확인 실패: ' + ', '.join(problems))
    body = sum(len(re.sub(r'\s', '', b[1])) for b in spec['blocks'] if b[0] in ('i', 'e'))
    print(f'완료: {path} (본문 {body}자, 형광펜 {x.count("markpenBegin")}곳, 줄바꿈 {x.count("lineBreak")}곳)')

if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('사용법: python3 make_hwpx.py 원고.json 결과.hwpx')
    build(json.load(open(sys.argv[1], encoding='utf-8')), sys.argv[2])
